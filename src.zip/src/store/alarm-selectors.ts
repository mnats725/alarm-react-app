import type { AlarmStore } from './alarm-store';
import type { Alarm } from '@/types/alarm.type';

export const selectAlarms = (s: AlarmStore): Alarm[] => s.alarms;

export const selectAlarmsSorted = (s: AlarmStore): Alarm[] =>
  [...s.alarms].sort((alarmA, alarmB) => (alarmA.time > alarmB.time ? 1 : -1));

export const selectById =
  (id: string) =>
  (s: AlarmStore): Alarm | undefined =>
    s.alarms.find((alarmItem) => alarmItem.id === id);
