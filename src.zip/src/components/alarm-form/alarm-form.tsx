import { useState } from 'react';

import { useAlarmStore } from '@/store/alarm-store';

import { WEEK_DAYS } from '@/constants/week-days.const';

import styles from './alarm-form.module.css';

import type { Weekday } from '@/types/alarm.type';

export type AlarmFormProps = {
  compact?: boolean;
};

export const AlarmForm = ({ compact }: AlarmFormProps): JSX.Element => {
  const isCompact = compact === true;

  const addAlarm = useAlarmStore((s) => s.addAlarm);

  const [time, setTime] = useState('07:00');
  const [label, setLabel] = useState('');
  const [volume, setVolume] = useState(1);
  const [repeat, setRepeat] = useState<Weekday[]>([]);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    addAlarm({ time, label, volume, repeat });
    setLabel('');
  };

  const onToggleRepeat = (code: Weekday): void => {
    const has = repeat.includes(code);
    if (has) {
      const next = repeat.filter((c) => c !== code);
      setRepeat(next);
      return;
    }
    const next = [...repeat, code];
    setRepeat(next);
  };

  return (
    <section className={styles.section} aria-labelledby="create-title">
      <h2 id="create-title" className={styles.title}>
        Создать будильник
      </h2>

      <form className={styles.form} onSubmit={onSubmit}>
        <fieldset className={styles.row} aria-label="Время">
          <label className={styles.label} htmlFor="alarm-time">
            Время
          </label>
          <input
            id="alarm-time"
            className={styles.time}
            type="time"
            value={time}
            onChange={(e) => setTime(e.currentTarget.value)}
            required
          />
        </fieldset>

        <fieldset className={styles.row} aria-label="Описание">
          <label className={styles.label} htmlFor="alarm-label">
            Метка
          </label>
          <input
            id="alarm-label"
            className={styles.input}
            type="text"
            placeholder="Например: Подъём"
            value={label}
            onChange={(e) => setLabel(e.currentTarget.value)}
          />
        </fieldset>

        <fieldset className={styles.row} aria-label="Громкость">
          <label className={styles.label} htmlFor="alarm-volume">
            Громкость
          </label>
          <input
            id="alarm-volume"
            className={styles.range}
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={volume}
            onChange={(e) => setVolume(Number(e.currentTarget.value))}
          />
          <output className={styles.out}>{Math.round(volume * 100)}%</output>
        </fieldset>

        <fieldset className={styles.week} aria-label="Повтор">
          <legend className={styles.legend}>Повтор</legend>
          <ul className={styles.days} role="list">
            {WEEK_DAYS.map((d) => {
              const active = repeat.includes(d.code as Weekday);
              return (
                <li key={d.code}>
                  <button
                    type="button"
                    className={active ? `${styles.day} ${styles.dayActive}` : styles.day}
                    aria-pressed={active}
                    onClick={() => onToggleRepeat(d.code as Weekday)}
                  >
                    {d.short}
                  </button>
                </li>
              );
            })}
          </ul>
        </fieldset>

        <div className={isCompact ? styles.actionsCompact : styles.actions}>
          <button type="submit" className={styles.primary}>
            Добавить
          </button>
        </div>
      </form>
    </section>
  );
};
