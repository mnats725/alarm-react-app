import { useMemo } from 'react';

import { useAlarmStore } from '@/store/alarm-store';
import { selectAlarmsSorted } from '@/store/alarm-selectors';

import { WEEKDAY_SHORT_BY_CODE } from '@/constants/week-days.const';

import styles from './alarm-list.module.css';

export type AlarmListProps = {
  title?: string;
};

export const AlarmList = ({ title }: AlarmListProps) => {
  const finalTitle = title ?? 'Мои будильники';

  const alarms = useAlarmStore(selectAlarmsSorted);
  const toggle = useAlarmStore((s) => s.toggleAlarm);
  const remove = useAlarmStore((s) => s.removeAlarm);

  const empty = useMemo(() => alarms.length === 0, [alarms.length]);

  return (
    <section className={styles.section} aria-labelledby="alarms-title">
      <h2 id="alarms-title" className={styles.title}>
        {finalTitle}
      </h2>

      {empty ? (
        <p className={styles.empty}>Список пуст — добавьте первый будильник выше.</p>
      ) : (
        <ul className={styles.list} role="list">
          {alarms.map((alarmItem) => (
            <li key={alarmItem.id} className={styles.item}>
              <article className={styles.card} aria-label={`${alarmItem.label || 'Будильник'} ${alarmItem.time}`}>
                <header className={styles.head}>
                  <time className={styles.time} dateTime={alarmItem.time}>
                    {alarmItem.time}
                  </time>
                  <div className={styles.controls}>
                    <button
                      type="button"
                      className={alarmItem.enabled ? `${styles.toggle} ${styles.on}` : styles.toggle}
                      aria-pressed={alarmItem.enabled}
                      onClick={() => toggle(alarmItem.id)}
                    >
                      {alarmItem.enabled ? 'Вкл' : 'Выкл'}
                    </button>
                    <button
                      type="button"
                      className={styles.remove}
                      onClick={() => remove(alarmItem.id)}
                      aria-label="Удалить"
                      title="Удалить"
                    >
                      ✕
                    </button>
                  </div>
                </header>

                <p className={styles.label}>{alarmItem.label || <span className={styles.muted}>Без метки</span>}</p>

                <footer className={styles.foot}>
                  <ul className={styles.repeat} role="list" aria-label="Повтор">
                    {alarmItem.repeat.map((weekday) => (
                      <li key={weekday} className={styles.badge}>
                        {WEEKDAY_SHORT_BY_CODE[weekday]}
                      </li>
                    ))}
                  </ul>
                </footer>
              </article>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};
